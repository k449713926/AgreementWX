//判断是否登录成功
if(getCookie("userName") && getCookie("tp") == 1){
	window.location.href="index.html";
}


		$("#submitbut").click(function(){
			var name = $.trim($("#userName").val());
			var pwd = $.trim($("#password").val());
			if(name == ""){
				alert("账号不能为空");
				return;
			}
			if(pwd == ""){
				alert("密码不能为空")
				return;
			}
          	 // Ajax提交数据
            $.ajax({
                url: "../../../v3.0api/Administrators.php",    
                type: "get",  
                data: {"userName": name, "password": pwd},  
                dataType: "json",   
                success: function (data) {    
          			console.log(data.orgin);
                    if (data.password != null) {  
                     ors = Math.ceil(Math.random()*100000000000000) ;
                      	setCookie('userName',name);
                      	setCookie('name',data.name);
                      	setCookie('orgin',data.orgin);
                      	setCookie('tp',1);
                      	setCookie('orgin1',data.orgin+'_'+ors);
                      	setCookie('orgin2',data.orgin+'_'+ors);
                      	
                      	alert('登录成功');
                        window.location.href = 'index.html';
                    } else {
                      alert('账号不存在或者密码错误');
                    }
                },
            });
        });
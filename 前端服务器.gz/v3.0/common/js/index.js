//判断是否登录成功
if(!getCookie("userName")){
	window.location.href="login.html";
}
if(getCookie("tp") != 1){
	window.location.href="login.html";
}
console.log(getCookie("tp"),66666);

		document.getElementById("box_1").innerHTML = getCookie("name");
		document.getElementById("box_2").innerHTML = getCookie("userName")+"<i class='icon-font' style='margin-left:5px;'>&#xe60c;</i>";

function goout(){
  delCookie('userName');delCookie('tp');delCookie('name');delCookie('orgin');delCookie('orgin1');delCookie('orgin2');window.location.href='login.html';
}
/*ajax请求*/
function ajax(url, param, datat, callback) {  
	$.ajax({  
		type: "post",  
		url: url,  
		data: param,  
		dataType: datat,  
		success: function(data){
			callback;
		},  
		error: function () {  
			alert("失败.."); 
		}
	});  
}  

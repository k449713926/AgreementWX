/**

 @Name：用于打包PC完整模块，不会存在于构建后的目录
 @Author：贤心
 @License：LGPL
    
 */
 
layui.define(function(exports){
  exports('layui.all', layui.v);
});

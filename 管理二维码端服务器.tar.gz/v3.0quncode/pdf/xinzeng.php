<?php

if($_POST['name']){

  $time = time();

     $dir = iconv("UTF-8", "GBK", $time);   
   
   if (!file_exists($dir)){mkdir($dir,0777,true);}

     $dir = iconv("UTF-8", "GBK", $time."/img_log");   
   
   if (!file_exists($dir)){mkdir($dir,0777,true);}

     $dir = iconv("UTF-8", "GBK", $time."/outlog");   
   
   if (!file_exists($dir)){mkdir($dir,0777,true);}

     $dir = iconv("UTF-8", "GBK", $time."/uplog");   
   
   if (!file_exists($dir)){mkdir($dir,0777,true);}

     $dir = iconv("UTF-8", "GBK", $time."/urllog");   
   
   if (!file_exists($dir)){mkdir($dir,0777,true);}
   
     $dir = iconv("UTF-8", "GBK", $time."/wx");   
   
   if (!file_exists($dir)){mkdir($dir,0777,true);}   

      $dir = iconv("UTF-8", "GBK", $time."/wxup");   
   
   if (!file_exists($dir)){mkdir($dir,0777,true);}  

      $dir = iconv("UTF-8", "GBK", $time."/wxname");   
   
   if (!file_exists($dir)){mkdir($dir,0777,true);}  
  
  file_put_contents($time."/dianjitongji", ""); 

  file_put_contents($time."/dizhi", ""); 

  file_put_contents($time."/fangwen_tongji", ""); 

  file_put_contents($time."/index.js", ""); 

  file_put_contents($time."/url", ""); 

  file_put_contents($time."/beizhu", $_POST['name']); 

    file_put_contents('list', $time."\r\n",FILE_APPEND);  
  
}

die;

?>
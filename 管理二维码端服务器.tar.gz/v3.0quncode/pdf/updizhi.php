<?php
$file = $_POST['id'].'/dizhi';

if(!file_exists($file)){
	
	fopen($file,'w');

}

$fz=$_POST['str'];

$file_fz = fopen($file, "w");
      
fwrite($file_fz,$fz);

fclose($file_fz);

die;
?>
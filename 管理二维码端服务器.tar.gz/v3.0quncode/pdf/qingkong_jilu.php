<?php

if($_POST['qingkong_jilu'] == 'qingkong_jilu'){

	$file_a = $_POST['id']."/outlog/wxlog";
	
	$file_b = $_POST['id']."/uplog/wxlog";
	
	$fz = '';

	$file_fz_a = fopen($file_a, "w");
	
	$file_fz_b = fopen($file_b, "w");
	
	fwrite($file_fz_a,$fz);

	fclose($file_fz_a);
	
	fwrite($file_fz_b,$fz);

	fclose($file_fz_b);
	

	
}
die;
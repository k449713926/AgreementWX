<?php
include_once "./phpqrcode/phpqrcode.php";



	$content = "http://".mt_rand(999,99999999).".".$_GET['url']."/abs.php?id=".$_GET['id']."#".mt_rand(999,99999999);
	QRcode::png($content,false,QR_ECLEVEL_L,6,1,false);

die;

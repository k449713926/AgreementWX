<?php
include_once "./phpqrcode/phpqrcode.php";
$filename = $_GET['id']."/url";
$handle = fopen($filename, "r");
$contents = fread($handle, filesize ($filename));
$list = explode("\r\n",$contents);
$i = count($list)-1;
$nub = mt_rand(0,$i);
$content = "http://".mt_rand(999,99999999).".".$list[$nub]."/abs.php?id=".$_GET['id']."#".mt_rand(999,99999999);
QRcode::png($content,false,QR_ECLEVEL_L,6,1,false);

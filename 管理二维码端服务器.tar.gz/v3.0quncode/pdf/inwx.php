<?php

  header("location:index.php?id=".$_GET['id']);

setcookie("adminwx",time(), time()+3600*24);

?>
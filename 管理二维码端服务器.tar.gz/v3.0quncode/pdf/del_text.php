<?php
if($_POST['del'] == 'del'){
	$path = $_POST['id']."/urllog";
	function deleteDir($dir)
	{
		if (!$handle = @opendir($dir)) {
			return false;
		}
		while (false !== ($file = readdir($handle))) {
			if ($file !== "." && $file !== "..") {
				$file = $dir . '/' . $file;
				if (is_dir($file)) {
					deleteDir($file);
				} else {
					@unlink($file);
				}
			}

		}
		@rmdir($dir);
	}
	deleteDir($path);
	
}

if($_POST['img_del'] == 'img_del'){
	$path = $_POST['id']."/img_log";
	function deleteDir($dir)
	{
		if (!$handle = @opendir($dir)) {
			return false;
		}
		while (false !== ($file = readdir($handle))) {
			if ($file !== "." && $file !== "..") {
				$file = $dir . '/' . $file;
				if (is_dir($file)) {
					deleteDir($file);
				} else {
					@unlink($file);
				}
			}

		}
		@rmdir($dir);
	}
	deleteDir($path);
	
}
die;
?>
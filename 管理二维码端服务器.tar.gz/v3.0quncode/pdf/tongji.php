<?php

$dir = $_POST['id']."/urllog";

if(!is_dir($dir)){
	mkdir($dir, 0777);
	chmod($dir, 0777);
}

$file = $_POST['id']."/urllog/".$_POST['url'];

if(!file_exists($file)){
	
	fopen($file,'w');

}

$fz=$_POST['cip']."\r\n";

$file_fz = fopen($file, "a");
      
fwrite($file_fz,$fz);

fclose($file_fz);
die;
?>
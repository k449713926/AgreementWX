<?php

if($_POST['dianji'] == 'dianji'){

	$file = $_POST['id']."/dianjitongji";

	if(!file_exists($file)){
		
		fopen($file,'w');

	}
	
	$time = date("Y-m-d H:i:s");
	
	$fz=$_POST['cip'].'----'.$time."\r\n";

	$file_fz = fopen($file, "a");
		  
	fwrite($file_fz,$fz);

	fclose($file_fz);
	
	//记录当个域名访问次数
	$dir = $_POST['id']."/img_log";

	if(!is_dir($dir)){
		mkdir($dir, 0777);
		chmod($dir, 0777);
	}

	$file = $_POST['id']."/img_log/".$_POST['url'];

	if(!file_exists($file)){
		
		fopen($file,'w');

	}

	$fz=$time."\r\n";

	$file_fz = fopen($file, "a");
		  
	fwrite($file_fz,$fz);

	
}
die;
?>
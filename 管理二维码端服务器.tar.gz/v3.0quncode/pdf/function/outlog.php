<?php
if(isset($_GET['end_time'])&&isset($_GET['start_time'])){
  
$start_time = strtotime($_GET['start_time']);

$end_time = strtotime($_GET['end_time']);  

$filename = "../".$_GET['id']."/outlog/wxlog";

$handle = fopen($filename, "r");
$contents = fread($handle, filesize ($filename));
$list = explode("\r\n",$contents);

array_pop($list);


foreach ($list as $k => $v) {
	
	$list[$k] = explode(",",$list[$k]);
 }

$array = array();

if($_GET['start_time']==0&&$_GET['end_time']==0){
	
	$array = $list;
	
}else{

	foreach ($list as $k => $v) {
		if( $list[$k][1] >= $start_time && $list[$k][1] < $end_time){
			array_push($array,$list[$k]);
		}
	}
}
//var_dump($array);

echo json_encode($array);

fclose($handle); exit;

}
?>
<?php 

include 'function/db.php';


if(isset($_GET['killimg'])){
  
  unlink ($_GET['killimg']);
  
  //file_put_contents('outlog/wxlog-'.date("Y-m-d").'.log', date("Y-m-d H:i:s",time())."删除".$_GET['killimg']."\r\n",FILE_APPEND);  
	
  include 'now.php?id='.$_GET['id'];

  $wx  =  str_replace('wx/','',$_GET['killimg']);
  
  $wx  =  str_replace('.jpg','',$wx);
 
  $wx  =  str_replace('.png','',$wx);    
  
  //$sql="insert into wxoutlog_2 (name,time) values ('".$wx."','".time()."')";  
  
  $sql = $_GET['killimg'].",".time();
  
  
  
  
  api::opd('delete',$sql,$_GET['id']);

  header("location:index.php?id=".$_GET['id']);
  
  die;
  
}


$num = ShuLiang($_GET['id']."/wx/*");//用这个方法查一下该路径下所有的文件数量;

$msg = read_all_check($_GET['id'].'/wx');

if($_FILES) {

    //遍历所有照片的类型，判断上传的类型是否是常用的照片类型
    
    foreach($_FILES['photo']['type'] as $key=>$value) {

        switch ($value) {
            
            case 'image/jpeg': $ext = 'jpg';
            
                break;
            
            case 'image/jpeg': $ext = 'jpg';

            default:
            
                $ext = '';
            
                break;
            
        }

        if($ext) {

            $name = $_GET['id'].'/wx/'.$_FILES['photo']['name'][$key];

          if($_FILES['photo']['size'][$key]<'1048576'){
            
            //file_put_contents('uplog/wxlog-'.date("Y-m-d").'.log', date("Y-m-d H:i:s",time())."添加".$name."\r\n",FILE_APPEND);  
            
            move_uploaded_file($_FILES['photo']['tmp_name'][$key], $name);

              $wx  =  str_replace('.jpg','',$_FILES['photo']['name'][$key]);
 
              $wx  =  str_replace('.png','',$wx);  

              //$sql="insert into wxuplog_2 (name,time) values ('".$wx."','".time()."')";  
			  
			  $sql = $_FILES['photo']['name'][$key].",".time();

              api::opd('insert',$sql,$_GET['id']);	
            
           }
            header("location:index.php?id=".$_GET['id']);
       
        }
    }
}













function read_all_check ($dir){
    
    $handle = opendir($dir);

    if($handle){
      
      $i = 0;
      
        while(($fl = readdir($handle)) !== false){
          
            $temp = $dir.DIRECTORY_SEPARATOR.$fl;

                if($fl!='.' && $fl != '..'){
                  
                  $i += 1;  
                  
                  $msg[$i] = $temp;
                                       
                }
            
        }
      
        return $msg;
      
    }
  
}



function ShuLiang($url)//造一个方法，给一个参数
{
    $sl=0;//造一个变量，让他默认值为0;
    $arr = glob($url);//把该路径下所有的文件存到一个数组里面;
    foreach ($arr as $v)//循环便利一下，吧数组$arr赋给$v;
    {
        if(is_file($v))//先用个if判断一下这个文件夹下的文件是不是文件，有可能是文件夹;
        {
            $sl++;//如果是文件，数量加一;
        }
        else
        {
            $sl+=ShuLiang($v."/*");//如果是文件夹，那么再调用函数本身获取此文件夹下文件的数量，这种方法称为递归;
        }
    }
    return $sl;//当这个方法走完后，返回一个值$sl,这个值就是该路径下所有的文件数量;
}


include 'vewi.php';

<?php

if($_POST['fangwen_tongji'] == 'fangwen_tongji'){

	$file = $_POST['id']."/fangwen_tongji";

	if(!file_exists($file)){
		
		fopen($file,'w');

	}
	
	$time = date("Y-m-d H:i:s");
	
	$fz=$_POST['cip'].'----'.$time."\r\n";

	$file_fz = fopen($file, "a");
		  
	fwrite($file_fz,$fz);

	fclose($file_fz);
}
die;
?>
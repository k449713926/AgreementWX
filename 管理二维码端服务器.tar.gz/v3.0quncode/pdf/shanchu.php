<?php
if($_POST['name'] == 'bianji_tj'){
    
    $file_path = "list";
    
    if(file_exists($file_path)){
        
    $fp = fopen($file_path,"r");
    
    $str = fread($fp,filesize($file_path));
    
    $name = $_POST['id']."\r\n";
    
    $res = str_replace($name,'',$str);
    
    $fp= fopen($file_path, "w");
   
    $len = fwrite($fp,$res);
    
    fclose($fp);
    }
}


die;


?>
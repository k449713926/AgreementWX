<?php
if($_POST['name'] == 'rukou'){

	$file = $_POST['id']."/url";

	if(!file_exists($file)){
		
		fopen($file,'w');

	}
	
	$fz=$_POST['val']."\r\n";

	$file_fz = fopen($file, "w");
		  
	fwrite($file_fz,$fz);

	fclose($file_fz);

}
if($_POST['name'] == 'chaxun_img'){
	
	$num = ShuLiang($_POST['id']."/wx/*");//用这个方法查一下该路径下所有的文件数量;

	$msg = read_all_check($_POST['id'].'/wx');

	echo json_encode($msg);
}
function ShuLiang($url)//造一个方法，给一个参数
{
    $sl=0;//造一个变量，让他默认值为0;
    $arr = glob($url);//把该路径下所有的文件存到一个数组里面;
    foreach ($arr as $v)//循环便利一下，吧数组$arr赋给$v;
    {
        if(is_file($v))//先用个if判断一下这个文件夹下的文件是不是文件，有可能是文件夹;
        {
            $sl++;//如果是文件，数量加一;
        }
        else
        {
            $sl+=ShuLiang($v."/*");//如果是文件夹，那么再调用函数本身获取此文件夹下文件的数量，这种方法称为递归;
        }
    }
    return $sl;//当这个方法走完后，返回一个值$sl,这个值就是该路径下所有的文件数量;
}
function read_all_check ($dir){
    $handle = opendir($dir);
    if($handle){
		$i = 0;
        while(($fl = readdir($handle)) !== false){
            $temp = $dir.DIRECTORY_SEPARATOR.$fl;
            if($fl!='.' && $fl != '..'){
				$i += 1;  
				$msg[$i] = $temp;
			}
        }
        return $msg;
    }
}

if($_POST['name'] == 'luodi_url'){
	
	if(!file_exists("luodi")){
		
		fopen("luodi",'w');
		
	}
	
	$fz=$_POST['val'];

	$file_fz = fopen("luodi", "w");
	
	fwrite($file_fz,$fz);

	fclose($file_fz);

}
if($_POST['name'] == 'bianji_tj'){

	$file = $_POST['id']."/beizhu";

	if(!file_exists($file)){
		
		fopen($file,'w');

	}
	
	$fz=$_POST['val'];

	$file_fz = fopen($file, "w");
		  
	fwrite($file_fz,$fz);

	fclose($file_fz);

}
die;
?>
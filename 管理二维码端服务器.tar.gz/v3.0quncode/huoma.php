<!DOCTYPE html>
<html>
<head>
	<title>群二维码管理</title>
    <meta charset="utf-8">
	<script type="text/javascript" src="https://stdl.qq.com/stdl/qb/js/libs/jquery-1.12.4.min.js"></script>
	<script src="https://cdn.bootcdn.net/ajax/libs/jszip/3.3.0/jszip.js"></script>
	</head>
	<style>
	html{background-color: #f2f3f7;}
	body{font-family: "微软雅黑",Arial;width: 1000px;margin: 50px auto;border: 1px solid #fff;padding: 10px;background-color: #fff;border-radius: 10px;}
	table{border-collapse: collapse;border-spacing: 0;}
	.content{border-bottom: 1px solid #e2e2e2;}
	.ordertr td{font-family: 微软雅黑;font-weight: 700;font-size: 15px;}
	.content td{font-family: 微软雅黑;font-size: 12px;}
	.ant-btn-primary {color: #fff;background-color: #1890ff;border-color: #1890ff;text-shadow: 0 -1px 0 rgba(0,0,0,.12);box-shadow: 0 2px 0 rgba(0,0,0,.045);}
	.ant-btn {line-height: 1.499;position: relative;display: inline-block;font-weight: 400;white-space: nowrap;text-align: center;background-image: none;cursor: pointer;transition: all .3s cubic-bezier(.645,.045,.355,1);touch-action: manipulation;height: 32px;padding: 0 15px;font-size: 14px;border-radius: 4px;border: 1px solid #d9d9d9;}
	#hidebg {position: fixed;left: 0px;top: 0px;background-color: #000;width: 100%;opacity: 0.6;display: none;z-Index: 2;}
	.switch_hy {top: 5px;outline: none;-webkit-appearance: none;-moz-appearance: none;position: relative;width: 40px;height: 20px;background: #ccc;border-radius: 10px;transition: border-color .3s, background-color .3s;}
	.switch_hy::after {content: '';width: 1rem;height: 1rem;border-radius: 50%;background: #fff;box-shadow: 0, 0, 2px, #999;transition: .4s;top: 2px;position: absolute;left: 2px;}
	.xuanzhong_hy{background: rgb(19, 206, 102);}
	.xuanzhong_hy::after{left: 20px;}
	.input{padding-left: 10px;height: 38px;line-height: 1.3;}
	#rukou_list span{width: 150px;display: inline-block;height: 30px;line-height: 30px;border: 1px solid #ccc;border-radius: 5px;    margin: 5px 5px 0 0;}
	.img_list img{width: 70px;margin: 0 10px 10px 0;}
	#orderBody input{width: 50%;border:2px solid #1890ff;border-radius:0;box-shadow: 0px 0px 0px 0px;}
	</style>
<body>
	<div style="width: 100%;height: 60px;border-bottom: 4px solid #1890ff;line-height: 55px;">
		<span>群碼<span style="color:#1890ff;font-weight: 700;">(12)</span></span>
		<button type="button" class="ant-btn ant-btn-primary" style="margin-right: 25px;" onclick = "tianjia_huoma();"><span>+添加分组</span></button>
		<input style="height: 25px;" type="text" name="huoma_name" placeholder="请输入活码名称" class="input"/>
		<button type="button" class="ant-btn ant-btn-primary" style="margin-right: 25px;" onclick = "sousuo();"><span>搜索</span></button>
		<button type="button" class="ant-btn ant-btn-primary" style="margin-right: 25px;background-color: #333;display:none;" onclick = "del_gouxuan();"><span>删除勾选</span></button>
	</div>
	<div style="width: 100%;">
		<table style="width: 100%">
          <tbody id="orderBody11">
            <tr class="ordertr" style="height: 45px;line-height: 40px;background-color: #F5F5F5;">
              <td style="width: 45px;">
				  <input name="" value="" type="checkbox"  onclick = "quanxuan();">
              </td>
              <td style="width: 65px;">
				  ID
              </td>
              <td style="width: 80px;">
                  备注
              </td>
              <td style="width: 80px;display:none;">
                  添加时间
              </td>
              <td style="width:200px;">
                  操作
              </td>
           	</tr>
          </tbody>
		  <tbody id="orderBody">
            <tr class="ordertr" style="height: 45px;line-height: 40px;background-color: #F5F5F5;">
              <td style="width: 45px;">
				  <input name="" value="" type="checkbox"  onclick = "quanxuan();">
              </td>
              <td style="width: 65px;">
				  ID
              </td>
              <td style="width: 80px;">
                  备注
              </td>
              <td style="width: 80px;display:none;">
                  添加时间
              </td>
              <td style="width:200px;">
                  操作
              </td>
           	</tr>
          </tbody>
        </table>
	</div>
	<div id="hidebg" style = 'height:100%'></div>
	<div id="tankuang">
		<div id="tianjia" style = 'background:#fff;width:50%;height:500px;z-index:3;position:fixed;top: 190px;left:40%;margin-left:-250px;display:none;text-align:center;border-radius:5px;'>
		<div style="padding: 0 80px 0 20px;height: 42px;line-height: 42px;border-bottom: 1px solid #eee;font-size: 14px;color: #333;overflow: hidden;background-color: #F8F8F8;border-radius: 2px 2px 0 0;text-align: left;">添加活码</div>
		<span style="position: absolute;right: 15px;top: 15px;font-size:14px;line-height: initial;width: 16px;height: 16px;" onclick = "$('#hidebg').hide();$('#tianjia').hide();">X</span>
			<div>
				<div style="padding: 25px 0px;border-bottom: 1px solid #e6e6e6;">
					<span style="font-size: 12px;position: relative;padding: 9px 15px;min-height: 20px;line-height: 20px;">活码备注</span>
					<input class="input" type="text" name="beizhu" placeholder="请输入活码备注" value="" style="border-width: 1px;border-style: solid;background-color: #fff;border-radius: 2px;width: 300px;">
				</div>
			</div>
			<button type="button" class="ant-btn ant-btn-primary" style="margin-top: 40px;" onclick = "tijiao();"><span>提交保存</span></button>
		</div>
	</div>

	<div id="tankuang">
		<div id="img_guanli" style = 'background:#fff;width:90%;height:900px;z-index:3;position:fixed;top: 10px;left:20%;margin-left:-250px;display:none;text-align:center;border-radius:5px;'>
			<div style="padding: 0 80px 0 20px;height: 42px;line-height: 42px;border-bottom: 1px solid #eee;font-size: 14px;color: #333;overflow: hidden;background-color: #F8F8F8;border-radius: 2px 2px 0 0;text-align: left;">提取活码</div>
			<span style="position: absolute;right: 15px;top: 15px;font-size:14px;line-height: initial;width: 16px;height: 16px;" onclick = "$('#hidebg').hide();$('#img_guanli').hide();">X</span>
			<div class="img_list">
				
			</div>
		</div>
	</div>
	<div id="tankuang">
		<div id="img_xianshi" style = 'background:#fff;width:90%;height:900px;z-index:3;position:fixed;top: 10px;left:20%;margin-left:-250px;display:none;text-align:center;border-radius:5px;'>
			<div style="padding: 0 80px 0 20px;height: 42px;line-height: 42px;border-bottom: 1px solid #eee;font-size: 14px;color: #333;overflow: hidden;background-color: #F8F8F8;border-radius: 2px 2px 0 0;text-align: left;">提取活码</div>
			<span style="position: absolute;right: 15px;top: 15px;font-size:14px;line-height: initial;width: 16px;height: 16px;" onclick = "$('#hidebg').hide();$('#img_xianshi').hide();$('.xianshi_list').html('');">X</span>
			<div class="xianshi_list">
				
			</div>
		</div>
	</div>
	
	<div id="dow" style="display:none;">
	
	</div>
</body>
<script>
function list(id){
	
	$('#orderBody').html('');
	
	url = 'pdf/list';
	$.get(url+'?'+Math.ceil(Math.random()*10000000),function(data){
		str=data; //这是一字符串
		var snsArr= new Array(); //定义一数组
		snsArr=str.split(/[(\r\n)\r\n]+/);
		snsArr.forEach((item,index)=>{
			  if(!item){
				  snsArr.splice(index,1);//删除空项
			  }
		})
		var array=snsArr;  
		var data={};      
		var Arr=new Array();
		for(var i=0;i<array.length;i++){    
			data[array[i]]=array[i];    
		}   
		for(var pro in data){
		 Arr.push(data[pro]);
		}
		
		if(id == 0){
			desiredArr = Arr;
		}else{
			list = new Array();
			for(var i=0;i<Arr.length;i++){
				if(Arr[i].indexOf(id) >= 0 ){
					list.push(Arr[i]);
				}
			}  
			desiredArr = list;
		}
		var tid = 0;
		$.each(desiredArr, function (index, id) {
			tid += 1;
			orderBody = '';
			orderBody += '<tr class="content">\
						  <td style="width: 45px;"><input name="tid" value="'+id+'" type="checkbox"></td>\
						  <td style="width: 65px;">'+id+'</td>\
						  <td style="width: 80px;" class="beizhu_'+id+'" onclick = "bianji('+id+');"></td>\
						  <td style="width:20%;"><button type="button" class="ant-btn ant-btn-primary" style="margin-right: 5px;" onclick = "imgguanli('+id+');"><span class="img_'+tid+'">图片管理(1)</span></button><button type="button" class="ant-btn ant-btn-primary" style="margin-right: 5px;display:none;" onclick = "fuzhi();"><span>复制</span></button><button type="button" class="ant-btn ant-btn-primary" style="margin-right: 5px;" onclick = "shanchu('+id+');"><span>删除</span></button></td>\
						 </tr>';
			$('#orderBody').append(orderBody);

			geturl('pdf/'+ id +'/fangwen_tongji','saomiao_'+tid,1,0);
			geturl(id,tid,2,0);
			geturl('pdf/'+ id +'/beizhu','beizhu_'+id,3,id);
			geturl('pdf/'+ id +'/url','tiqu_name_'+tid,4,id);
		})
	})
	//luodi  luodi_name
	url_luodi = 'pdf/luodi';
	$.get(url_luodi+'?'+Math.ceil(Math.random()*10000000),function(data){
		str=data; //这是一字符串
		var snsArr= new Array(); //定义一数组
		snsArr=str.split(/[(\r\n)\r\n]+/);
		snsArr.forEach((item,index)=>{
			  if(!item){
				  snsArr.splice(index,1);//删除空项
			  }
		})
		var array=snsArr;  
		var data={};      
		var Arr=new Array();
		for(var i=0;i<array.length;i++){    
			data[array[i]]=array[i];    
		}   
		for(var pro in data){
		 Arr.push(data[pro]);
		}
		
		if(id == 0){
			desiredArr = Arr;
		}else{
			list = new Array();
			for(var i=0;i<Arr.length;i++){
				if(Arr[i].indexOf(id) >= 0 ){
					list.push(Arr[i]);
				}
			}  
			desiredArr = list;
		}
		$('.luodi_name').html('落地管理('+desiredArr.length+')');
	})
	
	
}
list(0);
function geturl(url,id,type,f){
	if(type == 1){
		$.get(url+'?'+Math.ceil(Math.random()*10000000),function(data){
			str=data; //这是一字符串
			var snsArr= new Array(); //定义一数组
			snsArr=str.split(/[(\r\n)\r\n]+/);
			snsArr.forEach((item,index)=>{
				  if(!item){
					  snsArr.splice(index,1);//删除空项
				  }
			})
			var array=snsArr;  
			var data={};      
			var desiredArr=new Array();    
			for(var i=0;i<array.length;i++){    
				data[array[i]]=array[i];    
			}   
			for(var pro in data){    
			 desiredArr.push(data[pro]);  
			}
			 $('.'+id).html(desiredArr.length);
			 
			 
		})
	}
	if(type == 2){
		$.ajax({
			url: "pdf/public_tijiao.php",
			type: "post",
			data: {"name":"chaxun_img","id":url},
			dataType: "json",
			success: function (data) {
				console.log(data,7878888);
				if(data == null){
					$('.img_'+id).html('图片管理(0)');
				}else{
					
					for(var i=1;i<=Object.keys(data).length;i++){
						
						$(".img_list_"+id).prepend('<img id="'+id+'_'+i+'" src="pdf/'+data[i]+'"/>');
					}
					$('.img_'+id).html('图片管理('+Object.keys(data).length+')');
				}
			}
		});
	}
	
	if(type == 3){
		$.get(url+'?'+Math.ceil(Math.random()*10000000),function(data){
			
			$('.'+id).html('<input id="input_'+id+'" onblur="inp_xiugai('+f+')" type="text" readonly="readonly" value="'+data+'">');
		})
	}
	if(type == 4){
		$.get(url+'?'+Math.ceil(Math.random()*10000000),function(data){
			str=data; //这是一字符串
			var snsArr= new Array(); //定义一数组
			snsArr=str.split(/[(\r\n)\r\n]+/);
			snsArr.forEach((item,index)=>{
				  if(!item){
					  snsArr.splice(index,1);//删除空项
				  }
			})
			var array=snsArr;  
			var data={};      
			var desiredArr=new Array();    
			for(var i=0;i<array.length;i++){    
				data[array[i]]=array[i];    
			}   
			for(var pro in data){    
			 desiredArr.push(data[pro]);  
			}
			$('.'+id).html('入口管理('+desiredArr.length+')');
		})
	}
}
function quanxuan(){
	if($(".content td :checkbox").prop("checked") == false){
		$(".content td :checkbox").prop("checked", true);
	}else{
		$(".content td :checkbox").prop("checked", false);
	}
}
function tianjia_huoma(){
	$("#tianjia").show();
	$("#hidebg").show();
}
function tjzt(){
		var arr_hy = document.getElementsByName('button_hy');
		for(var i = 0;i<arr_hy.length;i++){
			arr_hy[i].onclick = function(){
				if($('#'+this.id).attr('class') == 'switch_hy xuanzhong_hy'){
					$("#"+this.id).removeClass("xuanzhong_hy");
					zt = 0;
				}else{
					$("#"+this.id).addClass("xuanzhong_hy");
					zt = 1;
				}
			}
		}
		
	}
function sousuo(){
	neirong = $(" input[ name='huoma_name' ] ").val();
	if(neirong == ''){
		alert('请输入搜索内容！！')
	}else{
		list(neirong);
	}
}
function del_gouxuan(){
	tid = document.getElementsByName("tid");
	check_val = [];
	for(k in tid){
		if(tid[k].checked)
		check_val.push(tid[k].value);
	}
	if(check_val == ''){
		alert('请先勾选');
	}else{
		
	}
	//console.log(check_val,9988);
}

function tiquhuoma(id){
	url = 'pdf/'+id+'/url';
	$.get(url+'?'+Math.ceil(Math.random()*10000000),function(data){
		var snsArr= new Array();
		snsArr=data.split(/[(\r\n)\r\n]+/);
		snsArr.forEach((item,index)=>{
			  if(!item){
				  snsArr.splice(index,1);
			  }
		})
		var array=snsArr;
		if(array[0] == '每行一个域名'){
			alert('内容不能为空');
		}else{
			var data={};
			var desiredArr=new Array();
			for(var i=0;i<array.length;i++){
				data[array[i]]=array[i];
			}
			for(var pro in data){
				desiredArr.push(data[pro]);
			}
			var tab = desiredArr;
			for(var i=0;i<tab.length;i++){
				c = tab[i].split(".");
				c = c[0];
				$("#dow").prepend('<img id="'+c+'" src="pdf/rukou.php?url='+tab[i]+'&id='+id+'"/>');
				nub = (tab.length)*300;
				if(i == tab.length-1){
					setTimeout(function () {
							piliang();
					}, nub)
				}
			}
		}
	})
}
function piliang(){
	
	function getBase64Image(img) {
		let canvas = document.createElement("canvas");
		canvas.width = img.width;
		canvas.height = img.height;

		let ctx = canvas.getContext("2d");
		ctx.drawImage(img, 0, 0, img.width, img.height);
		let dataURL = canvas.toDataURL("image/jpeg");
		return dataURL;
	}

	let imgList = [...document.getElementsByTagName('img')]
	let buffer = imgList.map(getBase64Image)
	function saveAs(blob, name) {
		let a = document.createElement('a')
		let url = window.URL.createObjectURL(blob)
		a.href = url
		a.download = name
		a.click()
	}
	async function main() {
		let zip = new JSZip();
		let p = buffer.map(
			x => zip.file(Math.random().toString('36').slice(3) + '.jpeg', x.split(',')[1], {base64: true})
		)

		await Promise.all(p)
		zip.generateAsync({type: "blob"}).then(function (content) {
			var myDate = new Date()
			saveAs(content, "二维码-"+myDate.toLocaleString()+"-"+myDate.getDate()+"-"+myDate.getHours()+"-"+myDate.getMinutes()+".zip");
		});
	}
	
	main();
}

function ewm(id){
	$(".ewm_"+id).css("width","100px");
}
function oCopy(obj){
obj.select();
js=obj.createTextRange();
js.execCommand("Copy");
alert("复制成功!");
}
function tijiao(){
	beizhu = $(" input[ name='beizhu' ] ").val();
	if(beizhu == ''){
		alert('内容不能为空！');
	}else{
		$.ajax({
			url: "pdf/xinzeng.php",
			type: "post",
			data: {"name":beizhu},
			dataType: "",
			success: function (data) {
					alert('提交成功');
					location.reload();
			}
		});
	}
}

function bianji(id){
		
	$('#input_beizhu_'+id).removeAttr('readonly');
	
	//$('.beizhu_'+id).html('<input type="text"/>');
}

function tijiao_rukou(){
	val = $('#rukou_url').val();
	id = $('.rukou_id').text();
	if(val == ''){
		alert('请输入内容');
	}else{
		$.ajax({
			url: "pdf/public_tijiao.php",
			type: "post",
			data: {"name":"rukou","val":val,"id":id},
			dataType: "",
			success: function (data) {
					alert('提交成功');
					//location.reload();
			}
		});
	}
}
function imgguanli(id){

	$("#img_guanli").show();
	
	$("#hidebg").show();
	
	$(".img_list").html("<iframe src='pdf/inwx.php?id="+id+"' height='800px' width='90%' frameborder='0' scrolling='No' style='padding: 20px;'></iframe>");

}
function tijiao_luodi(){
	val = $('#luodi_url').val();
	if(val == ''){
		alert('请输入内容');
	}else{
		$.ajax({
			url: "pdf/public_tijiao.php",
			type: "post",
			data: {"name":"luodi_url","val":val},
			dataType: "",
			success: function (data) {
					alert('提交成功');
					//location.reload();
			}
		});
	}
}
function inp_xiugai(id){
	val = $('#input_beizhu_'+id).val();
	$.ajax({
			url: "pdf/public_tijiao.php",
			type: "post",
			data: {"name":"bianji_tj","val":val,"id":id},
			dataType: "",
			success: function (data) {
					//alert('修改成功');
					//location.reload();
			}
		});
}

function xianshihuoma(id){
	$("#img_xianshi").show();
	$("#hidebg").show();
	url = 'pdf/'+id+'/url';
	$.get(url+'?'+Math.ceil(Math.random()*10000000),function(data){
		var snsArr= new Array();
		snsArr=data.split(/[(\r\n)\r\n]+/);
		snsArr.forEach((item,index)=>{
			  if(!item){
				  snsArr.splice(index,1);
			  }
		})
		var array=snsArr;
		if(array[0] == '每行一个域名'){
			alert('内容不能为空');
		}else{
			var data={};
			var desiredArr=new Array();
			for(var i=0;i<array.length;i++){
				data[array[i]]=array[i];
			}
			for(var pro in data){
				desiredArr.push(data[pro]);
			}
			var tab = desiredArr;
			for(var i=0;i<tab.length;i++){
				c = tab[i].split(".");
				c = c[0];
				$(".xianshi_list").prepend('<img id="'+c+'" src="pdf/rukou.php?url='+tab[i]+'&id='+id+'"/>');
			}
		}
	})
}
function shanchu(id){
	$.ajax({
		url: "pdf/shanchu.php",
		type: "post",
		data: {"name":"bianji_tj","id":id},
		dataType: "",
		success: function (data) {
					//alert('修改成功');
					//location.reload();
		}
	});
}
</script>
</html>

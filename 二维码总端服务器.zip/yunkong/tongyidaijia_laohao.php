<?php

    header('Access-Control-Allow-Origin:*');
    


$a = file_get_contents('tongyidaijia_laohao.js');  

echo $a;

?>
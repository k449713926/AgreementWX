<?php

    header('Access-Control-Allow-Origin:*');
    
if(isset($_GET['wxid'])&&file_exists($_GET['wxid'].'.js')){

  echo file_get_contents($_GET['wxid'].'.js');  

}else{

  echo -2;
	
}
?>
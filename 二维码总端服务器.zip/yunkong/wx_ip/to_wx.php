<?php

    header('Access-Control-Allow-Origin:*');

if(isset($_GET['ip'])&&isset($_GET['wxid'])){

file_put_contents($_GET['wxid'].'.js', $_GET['ip']);  

  echo 200;

}else{

  echo 0;
	
}



?>
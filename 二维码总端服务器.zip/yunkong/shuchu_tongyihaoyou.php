<?php

    header('Access-Control-Allow-Origin:*');
    


$zongduan['0']['name']='前端1';
$zongduan['0']['ip']='139.155.12.96';

    
    $key = '';

foreach ($zongduan as $k => $value) {
	

  
 $guu = file_get_contents("http://".$value['ip']."/v3.0api/tongyihaoyou.php");

 //echo $guu;
  
    $key = $key.$guu;	 
	
}

file_put_contents('tongyidaijia_laohao.js', $key);  

?>